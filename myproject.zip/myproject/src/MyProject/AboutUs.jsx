import React from "react";

function AboutUs() {
  return (
    <div className="AboutusCode">
      <div>
      <h2 className="AboutUss">Our Infrastructure</h2>
      <ul>
        <li className="AboutUsList">
          Our journey has been full of challanges, innovational & achievements.
        </li>
        <li className="AboutUsList">
          We render complete specialized eye care service under one roof.
        </li>
        <li className="AboutUsList">
          We provide an assortment of international brands to satisfy your
          taste.
        </li>
        <li className="AboutUsList">
          We consider our staff to be our back bone & our strongest
          infrastructure.
        </li>
        <br />
        <li className="AboutUsList">
          *******************************************************************************************************************
        </li>
        <br />
        <li className="AboutUsList">
          <h2>Our Special Features</h2>
        </li>
        <br />
        <li className="AboutUsList">
          <h4>Zero Error Manufacturing</h4>
        </li>
        <li className="AboutUsList">
          <p>
            We manufacture the lenses according to the given prescription,
            Customer’s need & personality.
          </p>
        </li>
        <br />
        <li className="AboutUsList">
          *******************************************************************************************************************
        </li>
        <br />
        <li className="AboutUsList">
          <h4>Budget Spectacle Offer</h4>
        </li>
        <li className="AboutUsList">
          <p>To cater all groups, our spectacle range started from just:</p>
        </li>
      </ul>
      <div className="PrizeList">
        <ul>
          <li> Rs. 250/- (Frame + CR Lens) --> Single Vision</li>
          <li> Rs. 399/- (Frame+CR Lens) --> Bi-Focal </li>
          <li> Rs. 990/- (Frame + CR Lens) --> Progressive</li>
        </ul>
      </div>
      <br />
      <li className="star">
        *******************************************************************************************************************
      </li>
      <br />
      <div>
        <ul>
          <li className="AboutUsList">
            <h4>Free Home Delivery</h4>
          </li>
          <li className="AboutUsList">
            <p>We provide free home delivery in all over India.</p>
          </li>
        </ul>
        <br />
        <li className="star">
          *******************************************************************************************************************
        </li>
        <br />
      </div>
      <div>
        <ul>
          <li className="AboutUsList">
            <h4>Guaranteed Quality</h4>
          </li>
          <li className="AboutUsList">
            <p>We commited to quality.</p>
          </li>
          <li className="AboutUsList">
            <p>
              Each pair of glasses is inspected at least twice before deliver it
              to Customer.
            </p>
          </li>
        </ul>
        <br />
        <li className="star">
          *******************************************************************************************************************
        </li>
        <br />
      </div>
      <div>
        <ul>
          <li className="AboutUsList">
            {" "}
            <h4> Our Optometrists</h4>
          </li>
          <li className="AboutUsList">
            <p>Our store’s employees are academically talented & skilled. </p>{" "}
          </li>
          <li className="AboutUsList">
            <p>
              {" "}
              Our optometrists completed bachelor in optometry or equivalent
              qualification from premier optometry school.
            </p>
          </li>
          <li className="AboutUsList">
            <p>
              They examine & diagnose the conditions related to the visual
              system.
            </p>
          </li>
          <li className="AboutUsList">
            <p>
              They are being able to identify general health conditions that
              affect the eye such as diabetes & hypertension.
            </p>
          </li>
        </ul>
        <br/>
        <li className="star"> <h5>We pleased to serve you the best suitable spectacle that meet your personality and visual needs.</h5></li>
        <br />
        <li className="star">
          *******************************************************************************************************************
        </li>
        <br />
      </div>
      </div>
      
    </div>
  );
}

export default AboutUs;
