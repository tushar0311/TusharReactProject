import React from "react";
import Goggle from "./Goggle Shop Logo.png";
import Specs from "./Specs 3.jpg";
import GoggleShop from "./Goggle Shop Logo.png";
import SpecsOptical from "./Specs-Optical-2017-1-4.jpg";
import SpecsLogo from "./Shop Image.jpg";

function Home() {
  return (
    <div>
      <div className="card">
      <img src={Goggle} className="card-img" alt="Goggle Image" />
      <div className="card-img-overlay">
        <h1 className="card-title">SB VISION CARE </h1>
        <img className="specslogo" src={SpecsLogo} alt="Specs" />
        {/* <h3 className="card-text">
          Shop No.3, Vinod Apartment, Sai Chowk, Pashan - Sus Rd, Pune
        </h3> */}
        {/* <h3 className="card-text">
          Service options: In-store shopping · Delivery
        </h3> */}
        <div className="SpecsShop">
          <img className="specsshop" src={Specs} alt="Specs" />
          <img className="specsshop" src={GoggleShop} alt="Specs" />
          <img className="specsshop" src={SpecsOptical} alt="Specs" />
          
        </div>
        {/* <h3 className="InfoVC">
            Vision Care, the most trusted eye and vision care brand, driven to
            ignite the imagination of people in India through the fusion of most
            eloquent range of contemporary, elegant, sporty and ultramodern
            array of spectacle frames and sunglasses.Our Hospital Projects are
            governed by Visioncare Optolab Pvt. Ltd. A sister concern of
            Visioncare Optics Pvt. Ltd. Founded in the year 2003, with our 10
            years of experience, we have successfully established as a
            destination for all our Vision related problems. We aim to bring the
            international standard Optical & Ophthalmic care through our
            prestigious stores. Our unique approach is matched only by the
            personal level of service, we provide to our Customers & the
            Professionalism with which we operate. 
          </h3> */}
      </div>
    </div>
      

    
    
      <div className="footerInfo">
        <footer>
          <h5><b>Service Option:</b> In-store shopping · Delivery</h5> 
          <h5><b>Address:</b> Shop No.3, Vinod Apartment, Sai Chowk, Pashan - Sus Rd, Pune, Maharashtra 411021</h5>
          <h5><b>Hours:</b> Open:- 9.30 am To 2.00pm and 4.30 pm To 9.00 pm</h5> 
          <h5><b>Phone:</b> +91-98814 81282</h5> 
          <h5><b>Email:</b> Shirish.bhalshankar@gmail.com</h5> 
          
         
          
        </footer>
      </div>
    </div>
  );
}

export default Home;
