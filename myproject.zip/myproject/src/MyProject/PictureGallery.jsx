import React from 'react'
import Image1 from './Images/Image-1.png'
import Image2 from './Images/Image-2.jpg'
import Image3 from './Images/Image-3.jpg'
import Image4 from './Images/Image-4.jpg'
import Image5 from './Images/Image-5.jpg'
import Image6 from './Images/Image-6.jpg'
import Image7 from './Images/Image-7.jpg'
import Image8 from './Images/Image-8.jpg'
import Image9 from './Images/Image-9.jpg'
import Image10 from './Images/Image-10.jpg'
import Image11 from './Images/Image-11.jpg'
import Image12 from './Images/Image-12.jpg'
import Image13 from './Images/Image-13.jpg'
import Image14 from './Images/Image-14.jpg'
import Image15 from './Images/Image-15.jpg'
import Image16 from './Images/Image-16.jpg'
import Image17 from './Images/Image-17.jpg'
import Image18 from './Images/Image-18.jpg'
import Image19 from './Images/Image-19.jpg'
import Image20 from './Images/Image-20.jpg'
import Image21 from './Images/Image-21.jpg'
import Image22 from './Images/Image-22.jpg'
import Image23 from './Images/Image-23.jpg'
import Image24 from './Images/Image-24.jpg'

function PictureGallery() {
  return (
    <div className='PictureCode'>
      <img className='PictureGall ' src={Image1} alt="" />
      <img className='PictureGall' src={Image2} alt="" />
      <img className='PictureGall' src={Image3} alt="" />
      <img className='PictureGall' src={Image4} alt="" />
      <img className='PictureGall' src={Image5} alt="" />
      <img className='PictureGall' src={Image6} alt="" />
      <img className='PictureGall' src={Image7} alt="" />
      <img className='PictureGall' src={Image8} alt="" />
      <img className='PictureGall' src={Image9} alt="" />
      <img className='PictureGall' src={Image10} alt="" />
      <img className='PictureGall' src={Image11} alt="" />
      <img className='PictureGall' src={Image12} alt="" />
      <img className='PictureGall' src={Image13} alt="" />
      <img className='PictureGall' src={Image14} alt="" />
      <img className='PictureGall' src={Image15} alt="" />
      <img className='PictureGall' src={Image16} alt="" />
      <img className='PictureGall' src={Image17} alt="" />
      <img className='PictureGall' src={Image18} alt="" />
      <img className='PictureGall' src={Image19} alt="" />
      <img className='PictureGall' src={Image20} alt="" />
      <img className='PictureGall' src={Image21} alt="" />
      <img className='PictureGall' src={Image22} alt="" />
      <img className='PictureGall' src={Image23} alt="" />
      <img className='PictureGall' src={Image24} alt="" />
    </div>
  )
}

export default PictureGallery