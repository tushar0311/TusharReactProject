import React from 'react'
import SporyImage from './Sportframes.jpg'
import EconomicalImage from './Economicalframes.jpg'
import DesignerImage from './Designerframes.jpg'
import CorporateImage from './Corporateframes.jpg'
import CarlZeissImage from './CarlZeissLenses.jpg'
import EssilorImage from './EssilorLenses.bmp'
import KodakImage from './KodakLenses.jpg'
import GkbImage from './GKBlenses.jpg'
import AsahiliteImage from'./AsahiLiteLenses.png'
import AoImage from'./AOlenses.png'
import MonthlyDisposalImage from'./MonthlyDisposable.bmp'
import WeeklyDisposalImage from './Weeklydisposal.bmp'
import DailyDisposalImage from './onedaydisposal.png'
import ClsolutionImage from './C.L.Solution.jpg'
import ColorLensImage from './ColorLensImage.webp'

function Services() {
  return (
    <div className='SerciceCode'>
      <div>
      <h3 style={{fontSize:'40px'}}> Products and Sevices</h3>
     <ul>
      <li className='Frames'> <h4>Frames</h4> </li>
     </ul>
      <p className='FrameDetails'>Frames should be appropriate to your prescription.</p>
      <p className='FrameDetails'>Your lens and frame should complement each other.</p>
      <p className='FrameDetails'>It should suit your personality, taste and occupational needs.</p>
      <div className='FrameList'>
      <ul >
        <li>Sport frames</li>
        <li>Economical frames</li>
        <li>Designer frames</li>
        <li>Corporate frames</li>
      </ul>
      </div>
      <div>
        <img className='FrameImage' src={SporyImage} alt="" />
        <img className='FrameImage' src={EconomicalImage} alt="" />
        <img className='FrameImage' src={DesignerImage} alt="" />
        <img className='FrameImage' src={CorporateImage} alt="" />
      </div><br/><br/>
      <p>***************************************************************************************************************************************************************************************</p>
      <ul>
      <li className='Frames'> <h4>Lenses</h4> </li>
     </ul>
      <p className='FrameDetails'>We provide all renowned best brands like:</p>
      
      <div className='FrameList'>
      <ul >
        <li>Carl Zeiss lenses</li>
        <li>Essilor lenses</li>
        <li>Kodak lenses</li>
        <li>GKB lenses</li>
        <li>Asahi Lite lenses Japan</li>
        <li>AO lenses</li>
        <li>Mineral lenses</li>
        <li>Aspheric lenses</li>
        <li>ARC lenses</li>
        <li>Photochromatic lenses</li>
        <li>High Index lenses</li>
        <li>Progressive lenses</li>
      </ul>
      </div>
      <div>
        <img className='FrameImage' src={CarlZeissImage} alt="" />
        <img className='FrameImage' src={EssilorImage} alt="" />
        <img className='FrameImage' src={KodakImage} alt="" />
        <img className='FrameImage' src={GkbImage} alt="" />
        <img className='FrameImage' src={AsahiliteImage} alt="" />
        <img className='FrameImage' src={AoImage} alt="" />
      </div><br/><br/>
      <p>***************************************************************************************************************************************************************************************</p>
      <ul>
      <li className='Frames'> <h4>Contact Lenses</h4> </li>
     </ul>
      <p className='FrameDetails'>For better cosmetic look switch to contact lens.</p>
      
      <div className='FrameList'>
      <ul >
        <li>Monthly disposable</li>
        <li>Weekly disposable</li>
        <li>Daily disposable</li>
        <li>Toric lenses</li>
        <li>Color lenses</li>
      </ul>
      </div>
      <div>
        <img className='FrameImage' src={MonthlyDisposalImage} alt="" />
        <img className='FrameImage' src={WeeklyDisposalImage} alt="" />
        <img className='FrameImage' src={DailyDisposalImage} alt="" />
        <img className='FrameImage' src={ClsolutionImage} alt="" />
        <img className='FrameImage' src={ColorLensImage} alt="" />
      </div><br/><br/>
      <p>***************************************************************************************************************************************************************************************</p>
      <ul>
      <li className='Frames'> <h4>Our Upcoming Projects</h4> </li>
     </ul>
     <br/><br/>
      <p>***************************************************************************************************************************************************************************************</p>
      </div> 
      
    </div>
  )
}

export default Services