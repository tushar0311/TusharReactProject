import React, { useState } from 'react'

function Admin() {
    const [user,setuser]=useState({username:'', password:''});
    
    let handleUsernameChange=(e)=>{
        setuser(values=>({...values,username:e.target.value}))
      
    }
    let handlePasswordChange=(e)=>{
        setuser(values=>({...values,password:e.target.value}))
    }
    let handleSubmit = (e) =>{
        e.preventDefault();
      
    }
    
  return (
        
    <div className='formCode'>
            <form onSubmit={handleSubmit}>
                <h1>Login</h1><br/><br/>
                Usename<span style={{color:'red'}}>*</span> : <input type='text' value={user.username} onChange={handleUsernameChange}/><br/><br/>
                Password<span style={{color:'red'}}>*</span> : <input type='password' value={user.password} onChange={handlePasswordChange}/> <br/><br/>
                <button>Login</button><br/>
             </form>
             </div>
             
    


  )
}

export default Admin