import React from 'react'
import contactImage from './ContactUsImage.png'

function ContactUs() {
  return (
    <div className='ConatUsCode'>
      <h4>Contact Us</h4>
      <div className='contactcode'>
      <img style={{width:'200px',width:'200px'}} src={contactImage} alt="" />
       <h5> <b>Mobile:</b> 098814 81282</h5>
       <h5><b>Shop Name:</b> SB Vision Care</h5>
       <h5><b>Website:</b> www.sbvisioncare.co.in</h5>
       <h5><b>Email:</b></h5>
      </div>
    </div>
  )
}

export default ContactUs