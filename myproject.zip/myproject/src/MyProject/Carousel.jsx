import React from 'react'
import DajiInfo from './Daji.png'
import Goggle from "./Ranbir Image.jpg";
import Specs from "./Essilor.png";
import GoggleShop from "./Lumax.jpg";




const CarouselCode = () => {
  return (
    
<div id="carouselExampleControls" className="carousel slide" style={{ height:'80%px',width:'90%' }} data-ride="carousel">
  <div className="carousel-inner">
  <div className="carousel-item">
      <img className="d-block w-100" style={{height:'500px',width:'200px'}} src={DajiInfo} alt="Third slide"/>
    </div>
    <div className="carousel-item active">
      <img className="d-block w-100" style={{height:'500px',width:'200px'}} src={Goggle} alt="First slide"/>
    </div>
    <div className="carousel-item">
      <img className="d-block w-100" style={{height:'500px',width:'200px'}} src={Specs} alt="Second slide"/>
    </div>
    <div className="carousel-item">
      <img className="d-block w-100" style={{height:'500px',width:'200px'}} src={GoggleShop} alt="Third slide"/>
    </div>
   
  </div>
  <a className="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span ClassName="carousel-control-prev-icon" aria-hidden="true"></span>
    <span className="sr-only">Previous</span>
  </a>
  <a className="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span className="carousel-control-next-icon" aria-hidden="true"></span>
    <span className="sr-only">Next</span>
  </a>
</div>
    
  )
}

export default CarouselCode