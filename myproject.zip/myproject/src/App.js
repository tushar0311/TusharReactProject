
import './App.css';


import Home from './MyProject/Home'
import AboutUs from './MyProject/AboutUs'
import ContactUs from './MyProject/ContactUs'
import Services from './MyProject/Services'
import Admin from './MyProject/Admin'
import PictureGallery from './MyProject/PictureGallery';
import Carousel from './MyProject/Carousel';
import  "./Shop Image.jpg";
import { BrowserRouter as Router, Routes, Route, Link,NavLink } from "react-router-dom";




function App() {
  return (
    <div className="App">
      
      <Router>
        <div className='NavDev'>
          
          <ul className='myUlClass'>
            <li className='myLiClass'>
            <h4>SB VISION CARE & <br/> CONTACT LENS CLINIC </h4>
            </li>
            <li className='myLiClass'>
              <NavLink className='myNav' to="/" activeClassName='active'>Home</NavLink>
            </li>
            <li className='myLiClass'>
              <NavLink className='myNav' to="/about" activeClassName='active'>AboutUs</NavLink>
            </li>
            <li className='myLiClass'>
              <NavLink className='myNav' to="/PictureGallery" activeClassName='active'>Picture Gallery</NavLink>
              </li>
              <li className='myLiClass'>
              <NavLink className='myNav' to="/servie" activeClassName='active'>Products & Services</NavLink>
            </li>
            <li className='myLiClass'>
              <NavLink className='myNav' to="/contact" activeClassName='active'>ContactUs</NavLink>
            </li>
            <li className='myLiClass'>
              <NavLink className='myNav' to="/Admin" activeClassName='active'>Adminstartion</NavLink>
            </li>
          </ul>
           
        </div>
        <div className='CarouselClass'>
          <Carousel/>
          </div>
        
        <Routes>
          
        <Route exact path="/" element={<Home/>}></Route>
        <Route exact path="/about" element={<AboutUs/>}></Route>
        <Route exact path="/contact" element={<ContactUs/>}></Route>
        <Route exact path="/servie" element={<Services/>}></Route>
        <Route exact path="/Admin" element={<Admin/>}></Route>
        <Route exact path="/PictureGallery" element={<PictureGallery/>}></Route>

        </Routes>
      </Router>
      
    </div>
  );
}

export default App;
